"""Bounded model -> action -> observation loop with evidence-bound completion."""

import copy
import time
from datetime import datetime, timezone

from .schema import fingerprint, validate_action, validate_request
from .requirements import review_observation
from .revisions import revision_summary, failed_feedback


class ModelError(RuntimeError):
    """Sanitized backend error, safe to include in an artifact."""


class Agent:
    def __init__(self, model, tools, max_steps=12, on_event=None, cancel_event=None):
        if type(max_steps) is not int or not 1 <= max_steps <= 50:
            raise ValueError("max_steps 应为 1–50 的整数")
        self.model, self.tools, self.max_steps = model, tools, max_steps
        self.on_event, self.cancel_event = on_event, cancel_event

    def run(self, request):
        started = datetime.now(timezone.utc).isoformat()
        state = {"request": copy.deepcopy(request), "script": None, "retrieved": {},
                 "duration": None, "rules_check": None, "requirements_check": None,
                 "history": [], "max_steps": self.max_steps}

        def emit(kind, step):
            if self.on_event:
                self.on_event(copy.deepcopy({"kind": kind, "step": step, "script": state["script"],
                                             "duration": state["duration"], "rules_check": state["rules_check"],
                                             "requirements_check": state["requirements_check"],
                                             "trace": state["history"]}))

        def record(entry):
            state["history"].append(entry)
            emit("step", entry["step"])

        def result(status, message):
            return {"status": status, "message": message, "script": state["script"],
                    "duration": state["duration"], "rules_check": state["rules_check"],
                    "requirements_check": state["requirements_check"],
                    "sources": list(state["retrieved"].values()), "trace": state["history"],
                    "metadata": {"started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
                                 "provider": self.model.name, "evidence_kind": self.model.evidence_kind,
                                 "data_hash": self.tools.data_hash, "max_steps": self.max_steps,
                                 "steps": len(state["history"]), "synthetic_data": self.tools.synthetic_data,
                                 "completion_policy": "facts_duration_requirements_v3",
                                 "requirements_review_context": "current_rules_check_v1",
                                 "model_responses": sum(("model" in item) + ("review_model" in item)
                                                        for item in state["history"])}}
        try:
            missing = validate_request(request)
        except ValueError as exc:
            return result("invalid_input", str(exc))
        if missing:
            return result("needs_input", "请补充关键字段：" + "、".join(missing))
        state["script"] = copy.deepcopy(request.get("initial_script"))
        for step in range(1, self.max_steps + 1):
            if self.cancel_event and self.cancel_event.is_set():
                return result("cancelled", "已停止后续步骤，保留已有草稿和执行记录。")
            emit("thinking", step)
            tick = time.monotonic()
            try:
                action, meta = self.model.decide(copy.deepcopy(state), copy.deepcopy(self.tools.rules))
            except ModelError as exc:
                record({"step": step, "action": "model_error", "arguments": {},
                                         "decision_basis": "模型不可用，不能继续决策",
                                         "observation": {"ok": False, "error": str(exc)}})
                return result("blocked", "模型调用失败，未完成；见执行记录。")
            if self.cancel_event and self.cancel_event.is_set():
                return result("cancelled", "当前模型调用已返回，已停止执行后续动作。")
            try:
                validate_action(action)
            except ValueError as exc:
                record({"step": step, "action": "invalid_model_action", "arguments": {},
                                         "decision_basis": "结构校验失败，反馈模型调整",
                                         "observation": {"ok": False, "error": str(exc)}, "model": meta})
                continue
            name = action["action"]
            args = {}
            finish = None
            review_meta = {}
            if name == "search_materials":
                args = {"query": action["query"], "product_id": request["product_id"]}
                observation = self.tools.call(name, args)
                if observation["ok"]:
                    for material in observation["materials"]:
                        state["retrieved"][material["id"]] = material
            elif name == "write_script":
                args = {"script": copy.deepcopy(action["script"])}
                revision = revision_summary(state['script'], action['script'], failed_feedback(state))
                state["script"] = copy.deepcopy(action["script"])
                state["duration"] = state["rules_check"] = state["requirements_check"] = None
                observation = {"ok": True, "script_hash": fingerprint(state["script"]),
                               "revision": revision,
                               "message": "已更新草稿，必须对本稿重新运行时长、规则与需求检查"}
            elif name in {"estimate_duration", "check_rules", "check_requirements"}:
                if state["script"] is None:
                    observation = {"ok": False, "error": "no_script", "message": "请先生成草稿"}
                else:
                    args = {"script": copy.deepcopy(state["script"])}
                    if name == "estimate_duration":
                        args["target_seconds"] = request["target_seconds"]
                        if 'duration_mode' in request:
                            args['duration_mode'] = request['duration_mode']
                        observation = self.tools.call(name, args)
                        state["duration"] = observation
                    elif name == "check_rules":
                        args["retrieved_ids"] = sorted(state["retrieved"])
                        if 'expression_mode' in request:
                            args['expression_mode'] = request['expression_mode']
                        observation = self.tools.call(name, args)
                        state["rules_check"] = observation
                    else:
                        args['request'] = copy.deepcopy(request)
                        checked = state['rules_check']
                        args['rules_check'] = copy.deepcopy(checked) if checked and checked.get('script_hash') == fingerprint(state['script']) else None
                        try:
                            review, review_model = self.model.review(copy.deepcopy(request), copy.deepcopy(state['script']), copy.deepcopy(args['rules_check']))
                            review_meta = {'review_model': review_model}
                            if self.cancel_event and self.cancel_event.is_set():
                                observation = {'ok': False, 'error': 'review_cancelled'}
                            else:
                                observation = review_observation(review, request, state['script'], args['rules_check'])
                        except (ModelError, ValueError) as exc:
                            observation = {'ok': False, 'error': 'requirements_review_failed', 'message': str(exc)}
                        state['requirements_check'] = observation
            else:
                args = {"status": action["status"], "message": action["message"]}
                if action["status"] == "completed":
                    current = fingerprint(state["script"]) if state["script"] else None
                    checks = [state["duration"], state["rules_check"], state['requirements_check']]
                    passed = current and all(c and c.get("ok") and c.get("passed")
                                             and c.get("script_hash") == current for c in checks)
                    passed = passed and state['requirements_check'].get('request_hash') == fingerprint(request)
                    if passed:
                        observation = {"ok": True, "status": "completed", "script_hash": current}
                        explanation = action["message"].strip()
                        checked_note = "当前稿已通过来源、规则和预计时长检查，模型需求核对未发现遗漏；仍为可编辑脚本，未生成或发布视频。"
                        finish = ("completed", (explanation + "\n\n" if explanation else "") + checked_note)
                    else:
                        observation = {"ok": False, "error": "completion_gate_rejected",
                                       "message": "只有当前稿件的时长、规则和需求检查均通过，才能完成；遗漏需求时修订或说明缺口。"}
                elif action["status"] in {"needs_input", "blocked"} and action["message"].strip():
                    observation = {"ok": True, "status": action["status"]}
                    finish = (action["status"], action["message"])
                else:
                    observation = {"ok": False, "error": "invalid_finish_status"}
            record({"step": step, "action": name, "arguments": args,
                                     "decision_basis": action["reason"], "observation": observation,
                                     "model": meta, **review_meta, "elapsed_ms": round((time.monotonic() - tick) * 1000)})
            if finish:
                return result(*finish)
        return result("step_limit", "达到最大决策步数，任务未完成；保留草稿和已执行检查，不声明成功。")
