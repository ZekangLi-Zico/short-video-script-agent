# 提交清单与答题框模板

## 当前交付

本仓库包含第 4 题代码、可执行测试、输入与实际输出、运行 Trace、合成数据、说明文档和环境配置示例。GitHub 远程仓库尚未创建/上传，当前环境的 `gh` 未登录；不要把本地路径当作 GitHub URL。

当前 v4 有限修复版尚未形成新的 Git commit。旧基线 SHA 不代表当前修改，必须先将代码、文档和证据提交，再填写并推送新的完整 SHA。`小影科技笔试_第4题_v4有限修复版.zip` 是工作区快照，版本边界和文件哈希见包内 DELIVERY.json，不能当作已提交的 Git 版本。旧版 ZIP、源码备份与测试记录仍保留。

修复后新增50次真实模型网页对照实验，应用代码未变。`小影科技笔试_v4_50次真实模型对比实验.zip`是两轮实验和复盘的补充包，不是新的可运行项目包；提交仓库时同时加入本轮证据及更新文档。完整工作区核验3481项旧文件未变，补充包自校验仅覆盖其包内文件。

## 答题框模板

```text
选择题目：第 4 题——短视频脚本 Agent
GitHub URL：填写实际上传后的仓库地址
最终 commit SHA：填写 git rev-parse HEAD 输出的完整值

运行与评审入口：README.md
代码：src/
可执行测试：tests/；运行 python -m scripts.run_tests
修复后50次真实网页实验：evaluations/realistic-50-v4-20261104/（315次响应，35完成、15需补资料；非50次全通过）
定向真实模型与受控故障复测：evaluations/finite-v4-20261104/live-final/、web/
当前自动测试和离线验收：evaluations/finite-v4-20261104/tests-final/、mock-acceptance-final/（仅验证程序流程）
有限修复、前后对照及未解决问题：docs/10-finite-v4-report.md
50次网页实验前后比较及剩余问题：docs/11-v4-real50-comparison.md
修复前50次真实实验：evaluations/realistic-50-v3-20261104/（原记录保留）
历史v3优化记录：evaluations/quality-v3-20261104/；docs/09-quality-v3-report.md
历史修复版与50次网页测试：examples/repairs/、evaluations/realistic-50-20261103/
需求、方案、评估、AI 使用与复盘：docs/01–05

人工测试网页：双击 启动网页.cmd，或运行 python -m src.web --open；操作说明 docs/07-web-manual-test.md。
实现说明：Python 标准库 CLI 与本地网页共用 Agent；真实模型根据检索、估时、规则和需求核对结果选择后续动作。
支持资料不足、工具失败、超时修订和无依据宣传纠错，设置执行步数上限。
事实块逐字引用已检索资料；场景创作模式对标题、画面和连接语逐项语义审核，严格模式保留原批准表。
时长明确区分上限与目标区间，仍为文本估算；每次修订记录真实差异与失败反馈。
需求审核接收当前稿的实际估时，区分镜头最短停留与估计时长；运行中逐步保存检查点，意外中断后保留草稿并标为未完成。
真实模型受控故障实验与自然需求复测分开，未用Mock替代模型结果。

AI 辅助内容、个人贡献及已知限制：见 docs/04-ai-usage.md、docs/03-evaluation.md。
各阶段执行时间：最初CLI见examples/work-session.json，历史有限修复见examples/repairs/work-session.json，v3见evaluations/quality-v3-20261104/work-session.json，本轮见evaluations/finite-v4-20261104/work-session.json；均不等于个人手写耗时。
```

## 上传步骤

以下为待用户执行或另行授权的上传步骤，本项目准备过程没有向 GitHub 推送，也没有提交考试页面。

```bash
gh auth login
git add README.md src web tests scripts data docs evaluations examples requirements.txt .env.example
git add -f archives outputs/diagnostic outputs/latest outputs/web
git commit -m "Fix duration review context and preserve interrupted run evidence"
gh repo create short-video-script-agent --private --source=. --remote=origin --push
git rev-parse HEAD
```

如果已经建立远程仓库，使用该仓库自己的地址配置 origin，再 push；不要重复创建同名仓库。私有仓库必须给题目指定评审账号读取权限，截图未给出具体评审账号。

上述强制加入的目录是保留的旧版与合成运行证据（通常被.gitignore忽略）。v4完整ZIP另外包含根目录历史ZIP和校验JSON，以复核 baseline.json 的3128项历史文件清单。若GitHub只提交精简材料而不提交这些根目录历史归档，必须明确缩小完整性声明，或把完整ZIP作为同仓库Release附件并说明恢复方式；不能声称精简克隆已具备全部历史哈希对应文件。上传前按 `.gitignore` 和文件清单检查，不加入 `.runtime`、`.codex` 或登录配置。

## 最终核对

- 将全部材料放在同一个 GitHub 仓库中，确认 README 能打开。
- 确保提交的 commit SHA 与 GitHub 已推送的版本完全相同。
- 确认没有 `.env`、密钥、登录文件或隐私资料。
- 候选人实际阅读并复验后，如实补充个人改动与验证记录，不将 AI 编码记作个人手写。
- 题目提交按钮点击后不能修改；仓库、SHA 与评审权限确认后再交卷。
- ZIP 可作为页面附件补充，不能替代题目要求的 GitHub URL 和 commit SHA。
