# 提交清单与答题框模板

**当前工作区已更新至 v7.3 动作与对白编排版。** 155项自动测试通过；楼道和下棋两条真实网页模型验证及同需求对照见[本轮报告](../evaluations/staging-v7.3-20261106/README.md)。继承的调用修复见[故障修复报告](../evaluations/call-fix-v7.2-20261106/README.md)。旧版和全部历史记录保留，尚未重新制作最终提交ZIP或推送GitHub；下面的v7快照及20次实验均为历史结果。

**工作区补充：v7.1 已新增《城寨风云》编剧资料，见[说明](18-story-materials.md)。下面的 v7 ZIP 和20次实验仍是原历史快照，不包含这次扩展；本次并未重新打包或推送最终提交，不能将旧ZIP当成当前工作区。** 当时140项自动测试和定向网页验证单列在 `evaluations/story-pack-20261106/`。

历史 **v7自然旁白与连贯性优化版** 已包含代码、133项自动测试、20次真实网页记录和前后对照。主报告：[17-v7-natural-voice.md](17-v7-natural-voice.md)；精选证据：[examples/v7-live](../examples/v7-live/evaluation.md)。

最新快照：`小影科技笔试_第4题_v7_自然旁白与20次复测提交包.zip`。包内DELIVERY.json记录文件哈希，旧源码及全部实验记录保留；旧根目录ZIP保留本地，不重复嵌套。12006项历史哈希针对工作区，新包按自己的DELIVERY.json核验。

**尚未推送最终Git commit或交卷。** 本地没有GitHub远程；旧SHA不是最终提交。需填写实际仓库URL、推送后的完整SHA、私有仓库评审读取权限，以及候选人真实投入与本人复验。

```text
选择题目：第4题——短视频脚本Agent
GitHub URL：填写真实仓库地址
最终commit SHA：填写已推送的完整SHA

运行入口：README.md
当前动作与对白编排及对照：evaluations/staging-v7.3-20261106/README.md
此前故障修复及对照：docs/19-call-reliability.md
自然旁白的历史对照：docs/17-v7-natural-voice.md
需求、设计、评估、AI使用、复盘：docs/01–05
精选输入、实际输出和Trace：examples/v7-live/
历史20次网页实验：evaluations/natural-20-v7-20261105/
当前155项测试：evaluations/staging-v7.3-20261106/automated-final/
最新两条网页编排验证：evaluations/staging-v7.3-20261106/

启动网页：python -m src.web --open
自动测试：python -m scripts.run_tests
离线入口：python -m src.cli --provider mock --input examples/inputs/normal.json --output outputs/demo
真实模型：网页选择Codex，或按README配置模型API。

20次真实模型网页实验已逐次保存；其中19条有旁白，文本通读“可直接试配音”由8/19变为13/19，另1条静音稿单列。133项自动测试通过。
通读由参与开发的AI助手完成，非真人盲评或实际配音；运行状态与文案质量分开。全部原需求未改，47项测试版本文件和12006项历史文件哈希不变。
模型依据实际工具结果决定改稿、补查或停止，保留来源、声画时长和完整执行记录。
AI辅助、个人贡献和实际投入时间据实填写，见docs/04-ai-usage.md。
```

## 最后提交

1. 亲自运行并理解一条有效修订链，填写本人时间与复验记录。
2. 同一GitHub仓库放入代码、文档、examples、evaluations及archives，不加入凭证、.env、.runtime或隐私资料。
3. 创建最终commit并推送，核对远程README、Trace及权限，再填写URL和完整SHA。ZIP不能代替题目要求的GitHub交付。

```bash
git add README.md PRODUCT.md DESIGN.md src web tests scripts data docs evaluations examples requirements.txt .env.example .gitignore run.ps1 启动网页.cmd
git add -f archives
git commit -m "Improve coherent spoken copy with twenty preserved real-model comparisons"
git remote add origin <实际仓库URL>
git push -u origin HEAD
git rev-parse HEAD
```

以上命令尚未执行；已配置origin时不重复添加。新环境网页历史从outputs读取；完整提交包保留outputs。
