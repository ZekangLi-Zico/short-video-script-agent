# 提交清单与答题框模板

当前 **v6标题与效率优化版** 已包含代码、129项自动测试、50次真实网页记录和前后对照。主报告：[16-v6-titles-latency.md](16-v6-titles-latency.md)；精选证据：[examples/v6-live](../examples/v6-live/evaluation.md)。

最新快照：`小影科技笔试_第4题_v6_标题与效率优化50次复测提交包.zip`。包内DELIVERY.json记录文件哈希，旧源码及全部实验记录保留；旧根目录ZIP保留本地，不重复嵌套。9944项历史哈希针对工作区，新包按自己的DELIVERY.json核验。

**尚未推送最终Git commit或交卷。** 本地没有GitHub远程；旧SHA不是最终提交。需填写实际仓库URL、推送后的完整SHA、私有仓库评审读取权限，以及候选人真实投入与本人复验。

```text
选择题目：第4题——短视频脚本Agent
GitHub URL：填写真实仓库地址
最终commit SHA：填写已推送的完整SHA

运行入口：README.md
实际改进及前后对照：docs/16-v6-titles-latency.md
需求、设计、评估、AI使用、复盘：docs/01–05
精选输入、实际输出和Trace：examples/v6-live/
全部50次网页实验：evaluations/realistic-50-v6-20261105/
129项测试：evaluations/realistic-50-v6-20261105/development-tests/final/

启动网页：python -m src.web --open
自动测试：python -m scripts.run_tests
离线入口：python -m src.cli --provider mock --input examples/inputs/normal.json --output outputs/demo
真实模型：网页选择Codex，或按README配置模型API。

50次真实模型网页实验：38次完成、12次需补资料、0次模型失败，231次有效响应，231次调用尝试。
全部任务耗时中位数由314.1秒降至126.1秒；复用四个示例标题的稿件由22份变为0份。
模型依据实际工具结果决定改稿、补查或停止，保留来源、声画时长和完整执行记录。
AI辅助、个人贡献和实际投入时间据实填写，见docs/04-ai-usage.md。
```

## 最后提交

1. 亲自运行并理解一条有效修订链，填写本人时间与复验记录。
2. 同一GitHub仓库放入代码、文档、examples、evaluations及archives，不加入凭证、.env、.runtime或隐私资料。
3. 创建最终commit并推送，核对远程README、Trace及权限，再填写URL和完整SHA。ZIP不能代替题目要求的GitHub交付。

```bash
git add README.md PRODUCT.md DESIGN.md src web tests scripts data docs evaluations examples requirements.txt .env.example .gitignore run.ps1 启动网页.cmd
git add -f archives
git commit -m "Improve scenario titles and reduce model waiting with preserved evidence"
git remote add origin <实际仓库URL>
git push -u origin HEAD
git rev-parse HEAD
```

以上命令尚未执行；已配置origin时不重复添加。新环境网页历史从outputs读取；完整提交包保留outputs。
