# 提交清单与答题框模板

当前 **v5效果优化版** 的代码、118项自动测试、50次真实网页记录、逐例对比和报告已在本地整理。三项优化是有依据的改写/翻译、声画节拍、可拍分镜。主报告为 [15-v5-effective-scripts.md](15-v5-effective-scripts.md)，精选证据为 [examples/v5-live](../examples/v5-live/evaluation.md)。

最新快照：`小影科技笔试_第4题_v5_效果优化与50次复测提交包.zip`。包内DELIVERY.json记录各文件哈希；旧源码归档、全部测试及失败记录保留。根目录已有旧ZIP保留在本地，不重复嵌套进新包；历史7,788项哈希核验针对开发工作区，新包自身按DELIVERY.json核验。

**尚未推送最终Git commit或交卷。** 本地无GitHub远程，旧基线SHA不能标作最终版本。需要真实仓库URL、推送后的完整SHA、私有仓库的评审读取权限；候选人实际投入时间与本人复验也须据实填写。

## 答题框模板

```text
选择题目：第4题——短视频脚本Agent
GitHub URL：填写实际仓库地址
最终commit SHA：填写已推送的完整SHA

运行和评审入口：README.md
当前效果及前后对照：docs/15-v5-effective-scripts.md
五分钟证据路线：docs/13-reviewer-and-practice-guide.md
需求、方案、评估、AI辅助与复盘：docs/01–05
精选输入、实际输出、Trace：examples/v5-live/
50次网页真实实验及逐例评阅：evaluations/realistic-50-v5-20261104/
118项自动测试：evaluations/realistic-50-v5-20261104/development-tests/final/

运行：python -m src.web --open
自动测试：python -m scripts.run_tests
离线入口：python -m src.cli --provider mock --input examples/inputs/normal.json --output outputs/demo
真实模型：网页选择Codex，或按README配置模型API。

新稿支持有来源的自然改写和翻译，明确旁白、屏幕文字和播放节拍。
实测双语需求由未完成变为28秒成稿，八秒三功能由超限变为6.3秒成稿。
50次真实实验共292次有效响应：36完成、12需补资料、2次模型超时；全部记录保留。
模型依据实际检索和检查结果调整下一步，宿主绑定同一稿件验证检查结果并限制12步。
AI辅助及个人贡献见docs/04-ai-usage.md；个人投入与复验记录据实填写。
```

## 最后提交步骤

1. 按五分钟路线亲自运行并理解至少一条实际修订链，填写本人时间与复验记录。
2. 在同一个GitHub仓库放入代码、文档、examples、evaluations及源码archives，勿加入凭证、.env、.runtime或私人资料。所有实验网页输出已复制到对应runs目录，便于集中审阅。
3. 创建最终commit、推送，打开远程README与Trace核对内容和读取权限，再复制完整SHA到答题框。

以下是待执行命令，本轮没有代为推送或交卷：

```bash
git add README.md PRODUCT.md DESIGN.md src web tests scripts data docs evaluations examples requirements.txt .env.example .gitignore run.ps1 启动网页.cmd
git add -f archives
git commit -m "Improve grounded expression, audiovisual timing and storyboard evidence"
git remote add origin <实际仓库URL>
git push -u origin HEAD
git rev-parse HEAD
```

已配置origin时不要重复添加。ZIP可以作为附件，不能替代题目指定的GitHub URL与SHA。新环境的网页历史由outputs读取，若使用精简仓库，先运行一次才会有历史；完整提交包保留outputs。
