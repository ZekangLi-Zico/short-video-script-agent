"""User-visible local build identity, also saved with each new run."""
APP_VERSION = 'v7-natural-voice'
