# 提交清单与答题框模板

## 当前交付状态

当前为 **v4.1 提交前优化版**。代码、测试、真实运行记录和文档已在本地整理，当前证据见 `evaluations/final-polish-20261104/`，改进与边界见 `docs/12-final-polish-report.md`。旧版源码、失败记录和前几轮 50 次实验继续保留。

同源码后续50次网页真实模型复测已完成：317次响应，36完成、14需补资料。最新报告为 `docs/14-v41-real50-comparison.md`，逐次证据为 `evaluations/realistic-50-v41-20261104/`。新快照 `小影科技笔试_第4题_v4.1_50次复测提交包.zip` 包含最新文档及记录；此前项目包和实验补充包不覆盖。本次只测试和更新材料，不改应用。

**还没有创建或推送最终 Git commit，也没有交卷。** 本地没有配置 GitHub 远程；旧基线 SHA 不能代表当前工作区。最终必须提交真实 GitHub URL、推送后的完整 commit SHA，并确认私有仓库对指定评审账号可读。截图没有给出评审账号，不能凭空填写。

本轮 ZIP 是可运行工作区快照，其 `DELIVERY.json` 记录包内各文件哈希。包内保留源码历史归档和评估记录，但避免把根目录既有大 ZIP 再层层打入；旧根 ZIP 保留在本地。`baseline.json` 的历史完整性核验针对开发工作区；仅解压本轮包不能声称具备清单中的所有旧根 ZIP。

## 答题框模板

```text
选择题目：第 4 题——短视频脚本 Agent
GitHub URL：填写实际上传后的仓库地址
最终 commit SHA：填写已推送的 git rev-parse HEAD 完整输出

运行与评审入口：README.md
五分钟证据路线：docs/13-reviewer-and-practice-guide.md
当前改进、实际验证与未解决问题：docs/12-final-polish-report.md
最新50次复测及修改前对照：docs/14-v41-real50-comparison.md
需求、方案、评估、AI 使用与复盘：docs/01–05
当前定向网页输入、输出、Trace、截图及模型诊断：evaluations/final-polish-20261104/runs/
当前自动测试：evaluations/final-polish-20261104/tests/（101项）
当前离线验收：evaluations/final-polish-20261104/mock-acceptance/（8组，不证明真实模型效果）
历史 v4 的50次真实网页实验：evaluations/realistic-50-v4-20261104/（315次响应，35完成、15需补资料；不是当前版本的50次测试）
当前 v4.1 的50次真实网页实验：evaluations/realistic-50-v41-20261104/（317次响应，36完成、14需补资料；全部结果保留）

运行：python -m src.web --open
自动测试：python -m scripts.run_tests
离线演练：python -m src.cli --provider mock --input examples/inputs/normal.json --output outputs/demo
真实模型：网页选择 Codex；或按 README 配置支持结构化输出的模型 API。

模型根据检索、估时、规则和需求核对的实际结果选择后续动作；宿主限制步数并验证完成证据。
交付分镜、旁白/字幕、预计总时长、素材来源、风险和状态；审稿备注单独呈现，不进入视频。
资料不足或工具失败如实标注；不编造产品能力，不以Mock冒充真实模型，不声称已生成或发布视频。
AI辅助范围、个人贡献和未核验部分见 docs/04-ai-usage.md。
```

## 提交操作

先按 `docs/13-reviewer-and-practice-guide.md` 亲自复验，填写真实个人投入时间、独立修改和验证；没有独立修改可以如实写“无”。此前的 AI 执行时间有分阶段记录，不能合并冒充个人手写耗时。本轮时间窗口保存在 `evaluations/final-polish-20261104/work-session.json`。

准备仓库时先检查 `.gitignore`，不加入 `.env`、`.runtime`、`.codex`、凭证或私人资料。所有题目材料应放在同一个仓库；证据目录和源码归档按需要显式加入。以下命令是待执行示例，本轮没有代为推送或交卷：

```bash
git add README.md PRODUCT.md DESIGN.md src web tests scripts data docs evaluations examples requirements.txt .env.example .gitignore run.ps1 启动网页.cmd
git add -f archives
git commit -m "Complete script Agent evidence and editorial review separation"
git remote add origin <实际仓库URL>
git push -u origin HEAD
git rev-parse HEAD
```

`outputs/web` 中本轮运行已完整复制到各实验的 `runs/`，便于评审在一处查看；网页默认最近历史仍从 outputs 读取。若提交精简仓库，须说明网页新环境先运行一次才有历史。若 README/报告引用了 outputs 中独有证据，须一并提交；本轮完整包保留这些 outputs。

已配置 origin 时不要重复添加；私有仓库权限应设置为题目指定评审账号可读。推送后重新打开远程 README 和一份 Trace，确认 SHA 和权限。ZIP 可以作为附件，不能替代 GitHub URL 和 SHA。交卷后不可修改，最终提交需由候选人确认完成。

## 保留的历史

历史 v4 项目包 `小影科技笔试_第4题_v4有限修复版.zip` 与 50 次对照补充包 `小影科技笔试_v4_50次真实模型对比实验.zip` 没有覆盖；更早源码和实验仍在 archives、examples、evaluations 中。复盘报告引用各自原始数据，不把新结果覆盖到旧失败记录。
