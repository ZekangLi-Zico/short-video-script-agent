# 短视频脚本 Agent · 第 4 题

给定主题、受众、平台、目标时长和风格，模型检索合成产品资料，编排有来源的分镜脚本，调用时长与规则检查，再根据实际观察修订或说明无法完成。

**从这里评审：** [最新50次真实网页复测](docs/14-v41-real50-comparison.md) · [五分钟证据路线](docs/13-reviewer-and-practice-guide.md) · [当前改进与限制](docs/12-final-polish-report.md) · [提交清单](docs/06-submission.md)

当前版本 **v4.1 提交前优化版**。在 v4 的估时审核上下文、异常保存修复之上，补齐批量验收的需求核对守卫，并将创作者审稿备注与视频内容分离。采用 Python 标准库、单 Agent、真实模型动态选择动作；默认最多 12 步。未增加原题不要求的生产部署或视频生成。

**当前验证：101 项自动测试通过、8/8 离线验收通过。** 本轮8组网页验证含 **7组真实模型运行、54次响应**，另1组为零调用校验：5完成、2需补资料、1持续故障停止。逐次记录见 `evaluations/final-polish-20261104/`。Mock、真实模型调用和语义评阅各自说明，completed 不等于创作质量满分。

**随后对同一版本完成50次真实模型网页复测：317次响应，36 completed、14 needs_input，记录50/50完整。** 修改前v4为35 completed、15 needs_input、315次响应；仅V31八字卡片由未完成变为完成。V36/V46的风险与修改说明放入独立备注，公开稿更清楚；仍有17份备注出现待检查或状态含混措辞，双语和短表达限制仍在。见[完整复盘](evaluations/realistic-50-v41-20261104/复盘报告.md)、[逐例评阅](evaluations/realistic-50-v41-20261104/逐条复盘.csv)。本次未修改应用，101项自动测试和8组Mock为此前同源码的验证记录，没有再次运行后冒充新增成绩。

| 想核对什么 | 当前入口 |
|---|---|
| 原题要求有没有落地 | [需求与验收映射](docs/01-requirements.md) |
| 模型如何根据观察调整 | [方案](docs/02-solution.md)、本轮 P03/P07/P08 的 Trace |
| 当前代码的输入、输出、网页截图与诊断 | [本轮证据索引](evaluations/final-polish-20261104/README.md) |
| 测试结果与未解决问题 | [评估](docs/03-evaluation.md)、[本轮报告](docs/12-final-polish-report.md) |
| AI 做了什么，候选人做了什么 | [AI 使用说明](docs/04-ai-usage.md)、[复盘](docs/05-retrospective.md) |

历史 v4 的 50 次网页实验有 315 次真实模型响应，35 completed、15 needs_input；这是当前复测的修改前对照，记录与新实验分开保留。v4与更早版本的比较见 [历史 50 次复盘](docs/11-v4-real50-comparison.md)。更早阶段见 [v4 修复](docs/10-finite-v4-report.md)、[v3 优化](docs/09-quality-v3-report.md)、[初次有限修复](docs/08-limited-repair-report.md)，原输出与失败记录保留，版本源码位于 `archives/`。

本地项目包尚未推送 GitHub，也未交卷。最终仍需填写实际仓库 URL、最终 commit SHA、确认评审读取权限，并由候选人如实补充个人投入时间和复验记录。

## 网页人工测试

Windows 双击根目录的 **`启动网页.cmd`**，或在 PowerShell 执行：

```powershell
.\run.ps1 -Mode web
```

浏览器打开 **http://127.0.0.1:8765/**。跨平台可用 `python -m src.web --open`；换端口用 `--port 8766`。

1. 填写主题、受众、平台、秒数和风格；选择“不超过目标秒数”或“接近目标（90%–100%）”。网页新任务默认场景创作，可切换严格引用；恢复旧历史会还原旧模式。
2. 选择“真实模型 · Codex”或“离线演练 · Mock”，点击“生成并检查”。
3. 在“脚本预览”看分镜、旁白、来源、估时与需求核对；在“执行过程”展开每步实际参数、返回结果和简短依据。需求核对是模型评估，仍需人工判断。
4. 运行完成后下载 Markdown、Trace 或 JSON；最近运行可重新打开、修改输入后再试。

真实模型使用本机已登录 Codex 的额度。Mock 是固定桩，页面全程标注，不能证明模型决策。模型 API 只有在服务启动前配置环境变量才可选。

每次结果保存在 `outputs/web/<运行ID>/`。运行时即可下载检查点；刷新页面可重新接上当前服务的进行中任务。重启服务后恢复最近32条记录：已保存结果正常显示，已退出进程遗留的检查点恢复为未完成，不自动调用模型续跑，也不接管另一个存活进程的任务。“停止后续步骤”等待当前模型调用返回。网页只在本机监听，每个服务实例一次执行一个任务。

完整操作与逐项核对见 [网页人工测试指南](docs/07-web-manual-test.md)。当前素材是虚构产品“剪影练习版”；开放场景表达不增加产品能力依据。

## 运行环境与安装

- Python **3.11 或以上**。运行、测试均只使用标准库，`requirements.txt` 无第三方依赖。
- 在仓库根目录运行下列命令。不需要数据库、部署或视频生成服务；CLI 和网页共用核心代码。
- 真实模型可选已登录的 Codex CLI，或者支持结构化 JSON 输出的模型 API。

```bash
python --version
python -m pip install -r requirements.txt
```

第二条为空依赖安装，可跳过。Windows 若 `python` 指向不可用的商店别名，可用已安装的 `py -3` 替换；本地也提供 `run.ps1`，自动寻找虚拟环境、Codex 附带 Python 或 PATH 中的 Python。

## 先离线验证

```bash
python -m src.cli --provider mock --input examples/inputs/normal.json --output outputs/demo
python -m scripts.run_tests
python -m scripts.evaluate --provider mock --output outputs/evaluation-mock
python -m scripts.verify_evidence
```

Windows 便捷入口：

```powershell
.\run.ps1 -Mode demo
.\run.ps1 -Mode test
.\run.ps1 -Mode evaluate
```

**Mock 是固定离线决策桩，只验证宿主流程、工具与异常处理，不证明真实模型的决策效果。** 不会在真模型失败时偷偷切换 Mock。每次运行必须显式指定 `--provider`，产物也标记证据类型。

## 真实模型入口 A：Codex CLI

自行安装可支持所选模型的 Codex CLI，并执行 `codex login`。程序依次寻找 `CODEX_BIN`、桌面环境提供的 `CODEX_APP_RUNTIME_CLI_PATH`、Windows 已安装 Codex 桌面应用的 CLI、PATH 中的 CLI。

```bash
python -m src.cli --provider codex --input examples/inputs/normal.json --output outputs/real
```

也可用 `.\run.ps1 -Mode live`。`CODEX_MODEL` 留空则使用 CLI 配置的模型；本仓库保存的真实记录使用的模型见各 Trace 的 `model.model` 字段。无需向项目复制登录凭证。

适配器把当前状态和工具结果作为输入，通过 `codex exec --ephemeral --sandbox read-only --output-schema` 获取一次结构化动作。业务工具由本项目执行。适配器不会保留 CLI 内部推理文本；如发现 CLI 调用额外 shell/MCP 等工具则拒绝该次结果。

## 真实模型入口 B：模型 API

`.env.example` 列出变量；**程序不会自动加载 `.env` 文件**。用终端环境变量设置，不能提交真实密钥。

```powershell
$env:MODEL_API_KEY = '<你的密钥>'
$env:MODEL_NAME = '<账号可用且支持结构化输出的模型名>'
$env:MODEL_BASE_URL = 'https://api.openai.com/v1'
$env:MODEL_API_STYLE = 'responses'
python -m src.cli --provider api --input examples/inputs/normal.json --output outputs/api
```

支持兼容接口时可将 `MODEL_API_STYLE` 设为 `chat`，调用 `/chat/completions`；默认调用 `/responses`。不同服务的模型与结构化输出支持并不相同。HTTP 401、超时和非法响应都返回明确失败，不提供虚构的成功结果。**API 适配器有契约测试，本次未用真实 API Key 联调。**

## 输入与输出

```json
{
  "topic": "介绍字幕功能",
  "audience": "第一次制作口播短视频的创作者",
  "platform": "抖音",
  "target_seconds": 30,
  "duration_mode": "target",
  "expression_mode": "creative",
  "style": "清楚、友好、克制",
  "product_id": "demo-editor"
}
```

`target_seconds` 为1–300秒。`duration_mode=max`表示上限；`target`表示90%–100%的预计时长区间。`expression_mode=creative`允许原创场景、标题、连接语，必须通过完整表面的独立语义审核；`strict`保留原批准列表。旧JSON缺省仍为strict/max。可传`initial_script`检查修订旧稿，结构见 [超时场景输入](examples/mock/over_duration/input.json)。

target模式由本地工具检查时长区间；独立审核检查是否重复事实或空镜拖时长。两者不证明实际配音或成片节奏。所有block文字目前串行计时，英文旁白与中文屏幕卡同时显示的时长仍须人工校准。

每次运行目录包含：

| 文件 | 内容 |
|---|---|
| `input.json` | 原始输入，包含旧稿时原样保留 |
| `output.json` | 状态、结构化可编辑脚本、估时、风险、来源 |
| `script.md` | 人可读的分镜、旁白/字幕、镜头时长和引用 |
| `trace.jsonl` | 实际每一步的动作、参数、工具返回、简短依据与模型元数据 |
| `data_snapshot.json` | 本次使用的素材及品牌规则快照 |
| `manifest.json` | 运行时间、证据类型、数据哈希、步数上限、故障注入设置 |
| `checkpoint.json`、`run.json` | CLI/网页逐步落盘的最后检查点、运行标识和持有进程；检查点不是完成凭证 |
| `diagnostics/` | Codex每次调用的独立脱敏诊断，与Trace的call_id对应；不保存原始CLI输出或内部推理 |

`script.md` 便于人工编辑；需要程序复检时，将修改后的结构化稿件作为新输入的 `initial_script` 运行。程序不解析 Markdown 回写。

成功状态为 `completed`，CLI 退出码 0。`needs_input`、`blocked`、`step_limit`、`invalid_input` 的退出码为 2；这些状态可符合负向场景的预期，不能只看退出码判断验收。批量验收脚本在所有场景符合各自预期时返回 0。

## 验收与复现

```bash
python -m scripts.evaluate --provider codex --output outputs/evaluation-live
python -m scripts.evaluate --provider codex --output outputs/evaluation-live --case over_duration
python -m src.cli --provider mock --input examples/inputs/normal.json --fail-tool search_materials --fail-count -1 --output outputs/failure
```

共有正常、缺信息、无素材、持续工具失败、一次故障后恢复、超时修订、规则纠错、无法满足时长八个场景。按 `--case` 选部分运行时会合并该目录已有的验收索引，保留其他场景。

真实模型验收需要模型访问权限并消耗对应账号额度。模型输出具有随机性，新的运行可能采用不同路径或明确停止。

## 范围与取舍

- `data/` 全部是合成资料，虚构产品“剪影练习版”的功能不代表小影或其他真实产品。
- 事实块保留逐字引用。严格模式使用批准表达；场景创作允许原创，但其语义审核由模型判断，可能误判，不能视为事实正确性保证。
- 时长使用汉字/英文词/数字单位和镜头停留估算，不是 TTS 或成片实测。估算规则见 `docs/02-solution.md`。
- 默认最多 12 个动作步骤，可用 `--max-steps` 设置为 1–50；每次模型调用默认 180 秒，可用 `--timeout` 调整。需求核对动作会额外调用一次同后端模型，因而模型响应数可多于动作步数；总调用次数仍受步骤上限约束。
- 修改脚本会使旧检查失效。只有同一稿的来源/规则、时长、需求核对都通过，且核对绑定原请求，宿主才接受完成。需求核对使用同一后端的新上下文，不是独立模型认证，也不保证识别全部语义遗漏。
- 不生成图片、音频或视频，不接真实发布接口。

## 文件结构

```text
src/        模型决策循环、业务工具、真实模型接入、Mock、CLI、网页服务、报告
web/        本地网页表单、脚本预览与实际执行过程
tests/      单元、集成、适配器契约与反例测试
scripts/    批量验收及测试证据生成
examples/   输入、实际输出、执行记录、测试与验收结果
data/       合成素材与品牌规则
docs/       需求、方案、评估、AI 使用说明、复盘、提交清单
```

提交前按 [提交清单](docs/06-submission.md) 填写题号、GitHub URL 与最终 commit SHA。

## 接口参考

- [Codex 非交互运行](https://developers.openai.com/codex/noninteractive/)
- [结构化模型输出](https://developers.openai.com/api/docs/guides/structured-outputs)

本项目使用模型生成 JSON 动作再由宿主分派，不依赖某个 Agent 框架；API 适配器使用上述结构化输出协议。
