"""Human-readable script and machine-readable reproducibility artifacts."""

import json
import os
import tempfile
from pathlib import Path


def atomic_text(path, text):
    """Replace one artifact only after a complete, flushed write on the same disk."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='\n',
                                         dir=path.parent, prefix='.'+path.name+'.', suffix='.tmp', delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass


def atomic_json(path, content):
    atomic_text(path, json.dumps(content, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


def render_report(result):
    lines = ["# 短视频脚本运行结果", "", f"- 状态：`{result['status']}`",
             f"- 证据类型：`{result['metadata']['evidence_kind']}`",
             f"- 说明：{result['message']}", ""]
    script = result.get("script")
    if script:
        lines += [f"## {script['title']}", "", "> 未完成或检查失败时，下列内容仅为未通过验收的草稿。", ""]
        timings = {s["shot"]: s["estimated_seconds"] for s in (result.get("duration") or {}).get("shots", [])}
        for i, shot in enumerate(script["shots"], 1):
            lines += [f"### 分镜 {i}", "", f"画面：{shot['visual']}", "",
                      "旁白/字幕：" + "".join(b["text"] for b in shot["blocks"]), "",
                      "来源：" + ", ".join(b["source_id"] + "/" + b["fact_id"] for b in shot["blocks"] if b["source_id"]), "",
                      f"预计镜头时长：{timings.get(i, '未检查')} 秒", ""]
        if script.get('editor_notes'):
            lines += ['## 审稿备注（不进入视频，不计入时长）', '',
                      '供创作者核对修改与资料缺口，不是经过事实认证的产品介绍。', '',
                      script['editor_notes'], '']
    duration = result.get("duration") or {}
    revisions = [t['observation']['revision'] for t in result['trace'] if t.get('action') == 'write_script'
                 and t['observation'].get('revision', {}).get('before_hash')]
    if revisions:
        lines += ['## 实际修订', '', '位置按镜头索引比较；日志关联的是实际反馈，不证明模型因果推理。', '']
        for rev in revisions:
            lines += [f"- 修改：{', '.join(rev['changed_fields']) or '未改变'}；保留原镜头 {rev['unchanged_shots']} 个、原文案块 {rev['unchanged_blocks']} 个。",
                      '- 修订前失败检查：' + ', '.join(f['check'] for f in rev['feedback'])]
        lines += ['']
    if duration.get('duration_mode') == 'target':
        lines += [f"时长要求：{duration['min_seconds']}–{duration['target_seconds']} 秒（接近目标）。", '']
    lines += [f"预计总时长：{duration.get('total_seconds', '未检查')} 秒（基于语速与镜头停留估算，非成片实测）。", "",
              "## 检查结果与来源", "", "```json", json.dumps(result.get("rules_check"), ensure_ascii=False, indent=2), "```", "",
              "## 需求覆盖核对", "", "以下为模型评估，可能漏判或误判，仍需人工确认。", "",
              "```json", json.dumps(result.get('requirements_check'), ensure_ascii=False, indent=2), "```", "",
              "## 执行路径", "", " → ".join(t["action"] for t in result["trace"]), "",
              "逐步参数、观察和简短决策依据见 trace.jsonl。未记录模型内部思维过程。", ""]
    return "\n".join(lines)


def save_run(directory, request, result, tools):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    files = {"input.json": request, "output.json": {k: v for k, v in result.items() if k != "trace"},
             "data_snapshot.json": {"materials": tools.materials, "rules": tools.rules},
             "manifest.json": {**result["metadata"], "fault_injection": tools.initial_failures if hasattr(tools, "initial_failures") else {}}}
    for name, content in files.items():
        if name != 'output.json':
            atomic_json(directory / name, content)
    atomic_text(directory / "trace.jsonl", "".join(json.dumps(e, ensure_ascii=False, allow_nan=False) + "\n" for e in result["trace"]))
    atomic_text(directory / "script.md", render_report(result))
    atomic_json(directory / 'output.json', files['output.json'])
